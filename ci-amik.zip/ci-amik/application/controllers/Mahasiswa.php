<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mahasiswa_model');
    }

    public function index()
    {
        $data['title'] = 'Mahasiswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->getAll();
        $this->load->view('templates/header', $data);
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['title'] = 'Add Mahasiswa';
        
        $this->form_validation->set_rules('nim', 'NIM', 'required|is_unique[mahasiswa.nim]|exact_length[9]');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('prodi', 'Prodi', 'required');
        $this->form_validation->set_rules('konsentrasi', 'Konsentrasi', 'required');
        $this->form_validation->set_rules('semester', 'Semester', 'required');

        if ($this->form_validation->run() == FALSE)
                {
                    $this->load->view('templates/header', $data);
                    $this->load->view('mahasiswa/tambah', $data);
                    $this->load->view('templates/footer');    
                } else {
                    $this->Mahasiswa_model->addMahasiswa();
                    $this->session->set_flashdata('flash', 'Ditambah');
                    redirect('Mahasiswa');
                }   
    }

    public function hapus($id)
    {
        $this->Mahasiswa_model->hapusMahasiswa($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('Mahasiswa');
    }
}
