<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa_model extends CI_Model
{
    public function getAll()
    {
        $query = $this->db->query('SELECT * FROM mahasiswa ORDER BY id DESC');
        $mahasiswa = $query->result_array();
        return $mahasiswa;

        //return $this->db->get('mahasiswa')->result_array();
    }

    public function addMahasiswa()
    {
        $data = [
            "nim" => $this->input->post('nim', true),
            "nama" => $this->input->post('nama', true),
            "prodi" => $this->input->post('prodi', true),
            "konsentrasi" => $this->input->post('konsentrasi', true),
            "semester" => $this->input->post('semester', true)
        ];
        $this->db->insert('mahasiswa', $data);
    }

    public function hapusMahasiswa($id)
    {
        $this->db->delete('mahasiswa', ['id' => $id]);
    }
}
