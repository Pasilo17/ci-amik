<div class="container">
    <div class="row mt-3">
        <div class="col">

        <div class="row mb-3">
            <div class="col">
                <a href="<?= base_url('Mahasiswa/tambah'); ?>" class="btn btn-primary">Add</a>
            </div>
        </div>

        <?php if ($this->session->flashdata('flash')) : ?>
        <div class="row">
            <div class="col">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Data Berhasil!</strong> <?= $this->session->flashdata('flash'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    
      
    <table id="example" class="table table-striped table-bordered" style="width:100%">

        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Prodi</th>
                <th scope="col">Jurusan</th>
                <th scope="col">Semester</th>
                <th scope="col">Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $i = 1; ?>
            <?php foreach ($mahasiswa as $mhs) : ?>
                <tr>
                    <th scope="row"><?= $i ?></th>
                    <td><?= $mhs['nim']; ?></td>
                    <td><?= $mhs['nama']; ?></td>
                    <td><?= $mhs['prodi']; ?></td>
                    <td><?= $mhs['konsentrasi']; ?></td>
                    <td><?= $mhs['semester']; ?></td>
                    <td>
                        <a href="<?= base_url('Mahasiswa/hapus/'); ?><?= $mhs['id']; ?>" class="badge badge-danger">Delete</a>
                        <a href="<?= base_url('Mahasiswa/edit/'); ?><?= $mhs['id']; ?>" class="badge badge-primary">Update</a>
                    </td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; ?>
        </tbody>

    </table>
</div>
</div>
</div>
