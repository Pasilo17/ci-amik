<div class="container">
   
   <div class="row">
    <div class="col-6 mt-3">

    <div class="card">
    <h5 class="card-header"><?= $title; ?></h5>
    <div class="card-body">
        
    <form action="" method="post">

      <div class="form-group">
         <label for="nim">NIM</label>
         <input type="text" class="form-control" id="nim" name="nim">
         <small id="nim" class="form-text text-danger"><?= form_error('nim'); ?></small>
      </div>

      <div class="form-group">
         <label for="nama">Nama</label>
         <input type="text" class="form-control" id="nama" name="nama">
         <small id="nim" class="form-text text-danger"><?= form_error('nama'); ?></small>
      </div>

      <div class="form-group">
         <label for="prodi">Prodi</label>
         <input type="text" class="form-control" id="prodi" name="prodi">
         <small id="nim" class="form-text text-danger"><?= form_error('prodi'); ?></small>
      </div>

      <div class="form-group">
         <label for="konsentrasi">Konsentrasi</label>
         <input type="text" class="form-control" id="konsentrasi" name="konsentrasi">
         <small id="nim" class="form-text text-danger"><?= form_error('konsentrasi'); ?></small>
      </div>

      <div class="form-group">
         <label for="semester">Semester</label>
         <input type="text" class="form-control" id="semester" name="semester">
         <small id="nim" class="form-text text-danger"><?= form_error('semester'); ?></small>
      </div>

      <button type="submit" name="simpan" class="btn btn-primary">Add</button>
      
    </form>

    </div>
    </div>

    </div>
   </div>
    
</div>
