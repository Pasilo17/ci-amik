<div class="container">
    <div class="row mt-3">
        <div class="col">

        <div class="jumbotron">
            <h1 class="display-4">Hello, AMIK Luwuk Banggai!</h1>
            <p class="lead">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis quas, rerum, ex possimus quis dolor quo nesciunt perspiciatis minus beatae odit veniam harum sequi libero.</p>
            <hr class="my-4">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Praesentium tempore debitis assumenda quas pariatur quibusdam minima corporis quae deserunt ad eius provident sit, eum eaque.</p>
        </div>

        </div>
    </div>
</div>
